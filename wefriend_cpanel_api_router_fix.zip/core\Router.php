<?php

class Router {
    private $routes = [];

    // Yeni bir rota (endpoint) ekler
    public function add($method, $uri, $controller, $action) {
        $this->routes[] = [
            'method' => $method,
            'uri' => $uri,
            'controller' => $controller,
            'action' => $action
        ];
    }

    // Gelen isteği doğru controller ve metoda yönlendirir
    public function dispatch($requestMethod, $requestUri) {
        // Eğer sunucu root klasöründen başlatıldıysa ve cPanel ana dizine atıldıysa 
        // istekler "/auth/login" şeklinde veya "/api/auth/login" şeklinde gelebilir.

        // cPanel ana dizine kurulduğu için "/api" veya başka alt klasörler olmayabilir.
        // Ama yine de temizlik yapalım.
        
        // Soru işaretinden (query string) sonrasını at
        if (($pos = strpos($requestUri, '?')) !== false) {
            $requestUri = substr($requestUri, 0, $pos);
        }

        $basePath = '/api'; 

        if (strpos($requestUri, $basePath) === 0) {
            $requestUri = substr($requestUri, strlen($basePath));
        }

        // Eğer XAMPP gibi bir alt klasör üzerinden çalışıyorsa "/wefriend/api" de gelebilir.
        $basePath2 = '/wefriend/api';
        if (strpos($requestUri, $basePath2) === 0) {
            $requestUri = substr($requestUri, strlen($basePath2));
        }

        // Olası bir çift slash durumunu veya boşluğu temizle
        if ($requestUri == '' || $requestUri == '/') {
            $requestUri = '/';
        }

        // Endpoint eşleştirmesi
        foreach ($this->routes as $route) {
            if ($route['method'] == $requestMethod && $route['uri'] == $requestUri) {
                $controllerName = $route['controller'];
                $actionName = $route['action'];

                // Controller sınıfını başlat
                if (class_exists($controllerName)) {
                    $controller = new $controllerName();
                    
                    if (method_exists($controller, $actionName)) {
                        // İlgili metodu çağır
                        $controller->$actionName();
                        return;
                    } else {
                        Response::json(500, "Sistem Hatası: Metod ($actionName) bulunamadı.");
                    }
                } else {
                    Response::json(500, "Sistem Hatası: Controller ($controllerName) bulunamadı.");
                }
            }
        }

        // Hiçbir rota eşleşmezse 404 dön
        Response::json(404, "Endpoint bulunamadı. Lütfen URL'i kontrol edin.");
    }
}
?>